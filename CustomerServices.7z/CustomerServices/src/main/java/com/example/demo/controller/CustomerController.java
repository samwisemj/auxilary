package com.example.demo.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.pojo.Customer;
import com.example.demo.service.CustomerServiceLayer;

@RestController
@RequestMapping(value = "/customers")
public class CustomerController {

	@Autowired
	private CustomerServiceLayer service;

	public CustomerController() {
		super();
		// TODO Auto-generated constructor stub
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String add(@RequestBody Customer customer) {
		// Customer customer=new Customer(id, name, address);
		service.add(customer);
		return "Done";
	}
		
}
