package com.example.demo.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.CustomerRepo;
import com.example.demo.pojo.Customer;

@Service
public class CustomerServiceLayer {

	@Autowired
	private CustomerRepo dao;

	public CustomerServiceLayer() {
		super();
	}

	public void add(Customer customer) {
		dao.save(customer);
	}

	public ArrayList<Customer> viewAll() {
		return (ArrayList<Customer>) dao.findAll();
	}

	public void update(Customer customer) {
		dao.save(customer);
	}

	public void delete(int id) {
		dao.deleteById(id);
	}
}
